<!DOCTYPE html>
<html>
<head>
    <title>Edit Staff | POS System</title>
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>

<div class="topbar">
    <div class="brand">POS Management System</div>

    <div class="user-info">
        <?= esc(session()->get('full_name')) ?>
        <a href="/logout">Logout</a>
    </div>
</div>

<nav class="navbar">
    <a href="/products">Products</a>
    <a href="/customers">Customers</a>
    <a href="/users">Staff</a>
    <a href="/sales/new">Record Sale</a>
    <a href="/sales">Sales History</a>
</nav>

<div class="container">

    <div class="page-header">
        <div>
            <h1>Edit Staff</h1>
            <p>Update staff account information.</p>
        </div>

        <a href="/users" class="btn btn-secondary">
            Back to Staff
        </a>
    </div>

    <div class="card form-card">

        <?php if (isset($validation)): ?>
            <div class="error-box">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($user['avatar'])): ?>

            <div class="form-group">
                <label>Current Avatar</label>

                <img
                    src="/uploads/avatars/<?= esc($user['avatar']) ?>"
                    class="avatar"
                    alt="Current Avatar"
                >
            </div>

        <?php endif; ?>

        <form
            action="/users/update/<?= $user['id'] ?>"
            method="post"
            enctype="multipart/form-data"
        >

            <?= csrf_field() ?>

            <div class="form-group">
                <label>Username</label>

                <input
                    type="text"
                    name="username"
                    value="<?= old('username', $user['username']) ?>"
                >
            </div>

            <div class="form-group">
                <label>Full Name</label>

                <input
                    type="text"
                    name="full_name"
                    value="<?= old('full_name', $user['full_name']) ?>"
                >
            </div>

            <div class="form-group">
                <label>New Password</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Enter a new password"
                >

                <small>
                    Leave blank to keep the current password.
                </small>
            </div>

            <div class="form-group">
                <label>Replace Avatar</label>

                <input
                    type="file"
                    name="avatar"
                    accept=".jpg,.jpeg,.png"
                >

                <small>
                    Leave blank to keep the current avatar. JPG or PNG, maximum 2 MB.
                </small>
            </div>

            <button type="submit" class="btn btn-primary">
                Update Staff
            </button>

        </form>

    </div>

</div>

</body>
</html>