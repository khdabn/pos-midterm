<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer | POS System</title>
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>

<div class="topbar">
    <div class="brand">POS Management System</div>

    <div class="user-info">
        <?= esc(session()->get('full_name')) ?>
        <a href="/logout">Logout</a>
    </div>
</div>

<nav class="navbar">
    <a href="/products">Products</a>
    <a href="/customers">Customers</a>
    <a href="/users">Staff</a>
    <a href="/sales/new">Record Sale</a>
    <a href="/sales">Sales History</a>
</nav>

<div class="container">

    <div class="page-header">
        <div>
            <h1>Edit Customer</h1>
            <p>Update customer information.</p>
        </div>

        <a href="/customers" class="btn btn-secondary">
            Back to Customers
        </a>
    </div>

    <div class="card form-card">

        <?php if (isset($validation)): ?>
            <div class="error-box">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>

        <form action="/customers/update/<?= $customer['id'] ?>" method="post">

            <?= csrf_field() ?>

            <div class="form-group">
                <label>Full Name</label>

                <input
                    type="text"
                    name="full_name"
                    value="<?= old('full_name', $customer['full_name']) ?>"
                >
            </div>

            <div class="form-group">
                <label>Email</label>

                <input
                    type="email"
                    name="email"
                    value="<?= old('email', $customer['email']) ?>"
                >
            </div>

            <div class="form-group">
                <label>Phone</label>

                <input
                    type="text"
                    name="phone"
                    value="<?= old('phone', $customer['phone']) ?>"
                >
            </div>

            <button type="submit" class="btn btn-primary">
                Update Customer
            </button>

        </form>

    </div>

</div>

</body>
</html>